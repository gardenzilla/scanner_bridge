#!/bin/sh
LIB_PATH=$LD_LIBRARY_PATH
LIB_PATH=$LIB_PATH:/usr/lib/zebra-scanner/javapos/jni

CLASSPATH=$CLASSPATH:$LIB_PATH
CLASSPATH=$CLASSPATH:/usr/lib/zebra-scanner/javapos/jpos/xercesImpl.jar
CLASSPATH=$CLASSPATH:/usr/lib/zebra-scanner/javapos/jpos/xml-apis.jar
CLASSPATH=$CLASSPATH:/usr/lib/zebra-scanner/javapos/jpos/javaPOS114.jar
CLASSPATH=$CLASSPATH:/usr/share/zebra-scanner/javapos/xml
CLASSPATH=$CLASSPATH:/usr/share/zebra-scanner/javapos/config
CLASSPATH=$CLASSPATH:
CLASSPATH=$CLASSPATH:.

CLASSPATH=$CLASSPATH:/usr/lib/zebra-scanner/javapos/jpos/JposLogger.jar
CLASSPATH=$CLASSPATH:/usr/lib/zebra-scanner/javapos/jpos/JposServiceJniScale.jar
CLASSPATH=$CLASSPATH:/usr/lib/zebra-scanner/javapos/jpos/JposServiceJniScanner.jar
CLASSPATH=$CLASSPATH:/usr/lib/zebra-scanner/javapos/jpos/JposServiceOnScale.jar
CLASSPATH=$CLASSPATH:/usr/lib/zebra-scanner/javapos/jpos/JposServiceOnScanner.jar
CLASSPATH=$CLASSPATH:/usr/lib/zebra-scanner/javapos/jpos/JposServiceScanner.jar
CLASSPATH=$CLASSPATH:/usr/lib/zebra-scanner/javapos/jpos/JposServiceScale.jar
CLASSPATH=$CLASSPATH:/usr/share/zebra-scanner/samples/jpos-directio-app/JposTestDio.jar

java -cp $CLASSPATH -Djava.library.path=$LIB_PATH directiodemo.DirectIODemo
