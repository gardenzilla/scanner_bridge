/*   Copyright (c) 2016 Zebra Technologies - All Rights Reserved.
 * 
 * 
 *   Sample GTK application to demonstrate Zebra Scanner SDK and corescanner features to it's customers.
 *    
 *   bug me: ems.support@zebra.com
 */

#ifndef _DEBUG_H_
#define _DEBUG_H_


// system includes //
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <vector>
#include <boost/thread/mutex.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/numeric/conversion/cast.hpp>

#ifdef __DEBUG_PRINT__
#define debug_print(...)  { printf("%s:%s " ,__FILE__ ,__FUNCTION__ ) ;printf(" ") ; printf(__VA_ARGS__); printf("\n"); }
#else 
#define debug_print(...) do{}while(0) 
#endif

#endif  // _DEBUG_H_ //
