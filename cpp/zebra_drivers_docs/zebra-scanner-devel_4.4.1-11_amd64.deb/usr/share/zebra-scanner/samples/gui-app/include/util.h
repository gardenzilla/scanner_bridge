/*   Copyright (c) 2016 Zebra Technologies - All Rights Reserved.
 * 
 * 
 *   Sample GTK application to demonstrate Zebra Scanner SDK and corescanner features to it's customers.
 *    
 *   bug me: ems.support@zebra.com
 */

#ifndef _UTIL_H_
#define _UTIL_H_

#include <string>
#include <vector>
#include <sstream>
#include <iostream>
#include <CsUserDefs.h>
#include <vector>
#include "scanner.h"
std::string int2str(int i);
std::string scannerType2str(ScannerType scannerType );

std::vector<Scanner>  parseGetScannersOutXml(std::string outXml);

int  get_scanner_count(std::vector<Scanner> vecScanners, ScannerType scannerType );

int get_symbology_type( std::string outXml );
std::string get_decode_data( std::string outXml);

void barcodeMapInit();

std::string symbologyTypeToStr(int iSymbologyType,ScannerType scannerType);

ScannerType getScaannerTypeFromId(std::vector<Scanner> vecScanners , int id);

int getScannerIdFromBarcodeData (std::string strBarcodeData);


#endif // _UTIL_H_ //
