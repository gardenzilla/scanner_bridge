package directiodemo;

// Direct IO classes
import com.zebra.jpos.serviceonscanner.directio.DirectIOCommand;
import com.zebra.jpos.serviceonscanner.directio.DirectIOData;
import com.zebra.jpos.serviceonscanner.directio.DirectIOStatus;
import com.zebra.jpos.serviceonscanner.directio.DirectIODeviceData;
//import com.motorola.jpos.serviceonscale.directio.*;

import jpos.JposException;
import jpos.Scanner;


public class DirectIODemo extends javax.swing.JFrame {

	final String OPEN_SCANNERS="ZebraAllScanners";
	public static Scanner scannerObj = new Scanner();
	int scannerID=1;

	public DirectIODemo() {
		initComponents();

		String SetAttribInXML=
				"<attrib_list>\n" +
						"  <attribute>\n" +
						"    <id>140</id>\n" +
						"    <datatype>B</datatype>\n" +
						"    <value>2</value>\n" +
						"  </attribute>\n" +
						"</attrib_list>\n";

		txtSetInXml.setText(SetAttribInXML);
		setTitle("Direct IO Demo");
	}


	//   @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        txtGetInXml = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtSetInXml = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtOutput = new javax.swing.JTextArea();
        btnGetAll = new javax.swing.JButton();
        btnGetAttrib = new javax.swing.JButton();
        btnSet = new javax.swing.JButton();
        btnStore = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btnClear = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        btnOpen = new javax.swing.JButton();
        btnClose = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(800, 600));
        setResizable(false);

        txtGetInXml.setColumns(20);
        txtGetInXml.setRows(5);
        txtGetInXml.setText("<attrib_list>140</attrib_list>");
        jScrollPane1.setViewportView(txtGetInXml);

        txtSetInXml.setColumns(20);
        txtSetInXml.setRows(5);
        jScrollPane2.setViewportView(txtSetInXml);

        txtOutput.setColumns(20);
        txtOutput.setRows(5);
        jScrollPane3.setViewportView(txtOutput);

        btnGetAll.setText("Get All Attributes");
        btnGetAll.setEnabled(false);
        btnGetAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGetAllActionPerformed(evt);
            }
        });

        btnGetAttrib.setText("Get Attribute");
        btnGetAttrib.setEnabled(false);
        btnGetAttrib.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGetAttribActionPerformed(evt);
            }
        });

        btnSet.setText("Set Attribute");
        btnSet.setEnabled(false);
        btnSet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSetActionPerformed(evt);
            }
        });

        btnStore.setText("Store Attribute");
        btnStore.setEnabled(false);
        btnStore.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStoreActionPerformed(evt);
            }
        });

        jLabel1.setText("In Xml");

        jLabel2.setText("In Xml");

        jLabel3.setText("Output");

        btnClear.setText("Clear");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 153));
        jLabel4.setText("Direct IO Demo");

        btnOpen.setText("Open");
        btnOpen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOpenActionPerformed(evt);
            }
        });

        btnClose.setText("Close");
        btnClose.setEnabled(false);
        btnClose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCloseActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(568, 568, 568)
                                .addComponent(btnClose, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 590, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel2))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnStore, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSet, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 55, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 590, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel1))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnGetAll)
                                    .addComponent(btnGetAttrib, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnOpen, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 586, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnClear)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(btnOpen))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnGetAll)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnGetAttrib))
                .addGap(13, 13, 13)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnSet)
                                .addGap(5, 5, 5)
                                .addComponent(btnStore)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                        .addComponent(jLabel3))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnClose)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnClear))
                .addGap(82, 82, 82))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

	private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
		ClearOutput();
	}//GEN-LAST:event_btnClearActionPerformed


	//-------------------------------------------------------------------------------
	// Call DirectIO commands 
	//-------------------------------------------------------------------------------


	private void btnGetAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGetAllActionPerformed

		try 
		{ 
			ClearOutput();
			// GET ALL Attributes
			DirectIOData params = new  DirectIOData();
			int opCode= DirectIOCommand.RSM_ATTR_GETALL;
			int[] scnID= new int[1];
			scnID[0]=scannerID;
			params.inXML="";
			scannerObj.directIO(opCode, scnID, (Object) params);

			if (params.status==DirectIOStatus.STATUS_SUCCESS)   
			{
				UpdateTextArea("DirectIO command success \n\n"+params.outXml);
			}
			else 
			{
				UpdateTextArea("DirectIO command failed : "+params.status); 
			}
		}
		catch (JposException e)
		{
			UpdateTextArea("DirectIO  failed \nError code :"+e.getErrorCode()+"\nError message :"+e.getMessage()+"\n\n");
			e.printStackTrace();
		}

	}//GEN-LAST:event_btnGetAllActionPerformed


	private void btnGetAttribActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGetAttribActionPerformed

		try 
		{ 
			ClearOutput();
			// GET Attribute
			DirectIOData params = new  DirectIOData();
			int opCode= DirectIOCommand.RSM_ATTR_GET;
			int[] scnID= new int[1];
			scnID[0]=scannerID;
			params.inXML=txtGetInXml.getText();
			scannerObj.directIO(opCode, scnID, (Object) params);

			if (params.status==DirectIOStatus.STATUS_SUCCESS)   
			{
				UpdateTextArea("DirectIO command success \n\n"+params.outXml);
			}
			else 
			{
				UpdateTextArea("DirectIO command failed : "+params.status); 
			}
		}
		catch (JposException e)
		{
			UpdateTextArea("DirectIO  failed \nError code :"+e.getErrorCode()+"\nError message :"+e.getMessage()+"\n\n");
			e.printStackTrace();
		}

	}//GEN-LAST:event_btnGetAttribActionPerformed


	private void btnSetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSetActionPerformed

		try 
		{ 
			ClearOutput();
			// SET Attribute
			DirectIOData params = new  DirectIOData();
			int opCode= DirectIOCommand.RSM_ATTR_SET;
			int[] scnID= new int[1];
			scnID[0]=scannerID;
			params.inXML= txtSetInXml.getText();
			scannerObj.directIO(opCode, scnID, (Object) params);

			if (params.status==DirectIOStatus.STATUS_SUCCESS)   
			{
				UpdateTextArea("DirectIO command success");
			}
			else 
			{
				UpdateTextArea("DirectIO command failed : "+params.status); 
			}
		}
		catch (JposException e)
		{
			UpdateTextArea("DirectIO  failed \nError code :"+e.getErrorCode()+"\nError message :"+e.getMessage()+"\n\n");
			e.printStackTrace();
		}

	}//GEN-LAST:event_btnSetActionPerformed


	private void btnStoreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStoreActionPerformed

		try 
		{ 
			ClearOutput();
			// STORE Attribute
			DirectIOData params = new  DirectIOData();
			int opCode= DirectIOCommand.RSM_ATTR_STORE;
			int[] scnID= new int[1];
			scnID[0]=scannerID;
			params.inXML=txtSetInXml.getText();
			scannerObj.directIO(opCode, scnID, (Object) params);


			if (params.status==DirectIOStatus.STATUS_SUCCESS)   
			{
				UpdateTextArea("DirectIO command success");
			}
			else 
			{
				UpdateTextArea("DirectIO command failed : "+params.status); 
			}

		}
		catch (JposException e)
		{
			UpdateTextArea("DirectIO  failed \nError code :"+e.getErrorCode()+"\nError message :"+e.getMessage()+"\n\n");
			e.printStackTrace();

		}

	}//GEN-LAST:event_btnStoreActionPerformed


	private void btnOpenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOpenActionPerformed

		try
		{
			ClearOutput();
			scannerObj.open(OPEN_SCANNERS);
			UpdateTextArea("\n Open: success \n\n");
		}
		catch (JposException e1) {
			UpdateTextArea("Open: failed \nError code :"+e1.getErrorCode()+"\nError message :"+e1.getMessage()+"\n\n");
			e1.printStackTrace();
		}


		try
		{
			scannerObj.claim(5000);
			UpdateTextArea("\n Claim: success \n\n");
		}
		catch (JposException e1) {
			UpdateTextArea("Claim:  failed \nError code :"+e1.getErrorCode()+"\nError message :"+e1.getMessage()+"\n\n");
			e1.printStackTrace();
		}


		try
		{
			scannerObj.setDeviceEnabled(true);
			UpdateTextArea("\n Device enable success \n\n");
		}
		catch (JposException e1) {
			UpdateTextArea("Device enable failed \nError code :"+e1.getErrorCode()+"\nError message :"+e1.getMessage()+"\n\n");
			e1.printStackTrace();
		}

		try
		{ 

			// GET Scanners
			DirectIODeviceData params = new  DirectIODeviceData();
			int opCode= DirectIOCommand.GET_SCANNERS;
			int[] intObj=null;
			scannerObj.directIO(opCode,  intObj, (Object) params);


			if (params.status==DirectIOStatus.STATUS_SUCCESS)   
			{
				UpdateTextArea("DirectIO GetScanners : success \n\n"+params.outXml);
				UpdateTextArea("\n\nConnected scanners :\n");

				for (int n=0;n< params.scannerCount;n++)
				{
					UpdateTextArea(" Scanner ID : "+params.scannerIDs[n]+"\n");

				}
				UpdateTextArea("\n Selected scanner  ID : "+params.scannerIDs[0]+"\n");
				scannerID=params.scannerIDs[0];

				EnableControls();
			}
			else 
			{
				UpdateTextArea("DirectIO command failed : "+params.status); 
			}

		}
		catch (JposException e)
		{
			UpdateTextArea("DirectIO  failed \nError code :"+e.getErrorCode()+"\nError message :"+e.getMessage()+"\n\n");
			e.printStackTrace();
		}

	}//GEN-LAST:event_btnOpenActionPerformed


	private void btnCloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCloseActionPerformed


		try
		{
			ClearOutput();
			scannerObj.release();
			UpdateTextArea("Release: success \n\n");

		} 
		catch (JposException e1)
		{
			UpdateTextArea("Release:  failed \nError code :"+e1.getErrorCode()+"\nError message :"+e1.getMessage()+"\n\n");
			e1.printStackTrace();
		}

		try
		{
			scannerObj.close();
			UpdateTextArea("Close: success \n\n");
			DisableControls();
		}
		catch (JposException e2) {
			UpdateTextArea("Close: failed \nError code :"+e2.getErrorCode()+"\nError message :"+e2.getMessage()+"\n\n");
			e2.printStackTrace();
		}

	}//GEN-LAST:event_btnCloseActionPerformed


	public void UpdateTextArea(String text)
	{
		txtOutput.setText(txtOutput.getText()+text);
		System.out.println(text);
	}

	public void EnableControls()
	{
		btnGetAll.setEnabled(true);
		btnGetAttrib.setEnabled(true);
		btnSet.setEnabled(true);
		btnStore.setEnabled(true);
		btnClose.setEnabled(true);
		btnOpen.setEnabled(false);
	}

	public void DisableControls()
	{
		btnGetAll.setEnabled(false);
		btnGetAttrib.setEnabled(false);
		btnSet.setEnabled(false);
		btnStore.setEnabled(false);
		btnClose.setEnabled(false);
		btnOpen.setEnabled(true);
	}

	public void ClearOutput()
	{
		txtOutput.setText("");
	}

	public static void main(String args[]) {

		/* Create and display the form */
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new DirectIODemo().setVisible(true);
			}
		});
	}
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnClose;
    private javax.swing.JButton btnGetAll;
    private javax.swing.JButton btnGetAttrib;
    private javax.swing.JButton btnOpen;
    private javax.swing.JButton btnSet;
    private javax.swing.JButton btnStore;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextArea txtGetInXml;
    private javax.swing.JTextArea txtOutput;
    private javax.swing.JTextArea txtSetInXml;
    // End of variables declaration//GEN-END:variables
}
