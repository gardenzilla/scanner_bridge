#!/bin/sh
# 
# File:   remote-management.sh
# Execute the remote management tool
# Author: Zebra Technologies
#
# Created on Jan 11, 2019, 7:31:26 PM
#

LIB_PATH=$LD_LIBRARY_PATH
LIB_PATH=$LIB_PATH:/usr/lib/zebra-scanner/javapos/jni

CLASSPATH=$CLASSPATH:$LIB_PATH
CLASSPATH=$CLASSPATH:/usr/lib/zebra-scanner/javapos/jpos/xercesImpl.jar
CLASSPATH=$CLASSPATH:/usr/lib/zebra-scanner/javapos/jpos/xml-apis.jar
CLASSPATH=$CLASSPATH:/usr/lib/zebra-scanner/javapos/jpos/javaPOS114.jar
CLASSPATH=$CLASSPATH:/usr/lib/zebra-scanner/javapos/jpos/JLogger.jar
CLASSPATH=$CLASSPATH:/usr/lib/zebra-scanner/javapos/jpos/logback-classic-1.2.3.jar
CLASSPATH=$CLASSPATH:/usr/lib/zebra-scanner/javapos/jpos/logback-core-1.2.3.jar
CLASSPATH=$CLASSPATH:/usr/lib/zebra-scanner/javapos/jpos/slf4j-api-1.7.25.jar
CLASSPATH=$CLASSPATH:/usr/share/zebra-scanner/javapos/xml
CLASSPATH=$CLASSPATH:/usr/share/zebra-scanner/javapos/config
CLASSPATH=$CLASSPATH:/usr/lib/zebra-scanner/javapos/jpos/JposLogger.jar
CLASSPATH=$CLASSPATH:/usr/lib/zebra-scanner/javapos/jpos/JposServiceJniScale.jar
CLASSPATH=$CLASSPATH:/usr/lib/zebra-scanner/javapos/jpos/JposServiceJniScanner.jar
CLASSPATH=$CLASSPATH:/usr/lib/zebra-scanner/javapos/jpos/JposServiceOnScale.jar
CLASSPATH=$CLASSPATH:/usr/lib/zebra-scanner/javapos/jpos/JposServiceOnScanner.jar
CLASSPATH=$CLASSPATH:/usr/lib/zebra-scanner/javapos/jpos/JposServiceScanner.jar
CLASSPATH=$CLASSPATH:/usr/lib/zebra-scanner/javapos/jpos/JposServiceScale.jar
CLASSPATH=$CLASSPATH:/usr/lib/zebra-scanner/javapos/jpos/JposRemoteManagement.jar
CLASSPATH=$CLASSPATH:/usr/share/zebra-scanner/remote-management/JposRemoteManagementTool.jar
CLASSPATH=$CLASSPATH:
CLASSPATH=$CLASSPATH:.


java -cp $CLASSPATH -Djava.library.path=$LIB_PATH jposremotemanagementtool.JposRemoteManagementTool

